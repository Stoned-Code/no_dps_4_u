

def list_to_tuple(li: list):
    return tuple(li)

def tuple_to_list(tup: tuple):
    li = []

    for item in tup:
        li.append(item)
    
    return li